import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useEffect, useState } from "react";
import { RefreshControl, ScrollView, StyleSheet, ToastAndroid, View } from "react-native";
import {
    Button,
    Card,
    Dialog,
    IconButton,
    Portal,
    Text,
} from "react-native-paper";
import { SafeAreaView } from "react-native-safe-area-context";

/* ------------------ Helpers ------------------ */

function getGreeting() {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    if (hour < 21) return "Good Evening";
    return "Good Night";
}

function formatTime(date) {
    if (!date) return "Just now";
    const d = new Date(date);
    if (isNaN(d.getTime())) return "Just now";

    return d.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
    });
}

/* ------------------ Screen ------------------ */

export default function Messages() {
    const userName = "Mohit Kumar";


    const [messages, setMessages] = useState([]);

    const [visible, setVisible] = useState(false);
    const [selectedId, setSelectedId] = useState(null);

    const [refreshing, setRefreshing] = useState(false);

    // 🔽 Track expanded messages
    const [expandedIds, setExpandedIds] = useState([]);

    const toggleExpand = (id) => {
        setExpandedIds((prev) =>
            prev.includes(id)
                ? prev.filter((i) => i !== id)
                : [...prev, id]
        );
    };

    const onRefresh = useCallback(() => {
        // Pull-to-refresh: fetch latest messages from server
        const doRefresh = async () => {
            setRefreshing(true);
            await fetchMessages();
            ToastAndroid.show("Pings Updated Successfully", ToastAndroid.SHORT);
            setRefreshing(false);
        };

        doRefresh();
    }, []);

    // Fetch messages from API and map to local format
    const fetchMessages = useCallback(async () => {
        const pingmeUsername = await AsyncStorage.getItem('pingme_username')
        console.log("Fetching messages for", pingmeUsername);
        console.log(`https://ping-me-api.vercel.app/log/${encodeURIComponent(
            pingmeUsername
        )}`);
        try {
            const res = await fetch(
                `https://ping-me-api.vercel.app/log/${encodeURIComponent(
                    pingmeUsername
                )}`
            );
            if (!res.ok) {
                console.error("Failed to fetch messages", res.status);
                return;
            }

            const data = await res.json();

            if (!Array.isArray(data)) return;

            const mapped = data
                .map((item) => ({
                    id: item._id,
                    title: item.username || "Unknown",
                    subtitle: item.message || "",
                    time: item.timestamp ? new Date(item.timestamp) : undefined,
                }))
                .sort((a, b) => {
                    const ta = a.time ? new Date(a.time).getTime() : 0;
                    const tb = b.time ? new Date(b.time).getTime() : 0;
                    return tb - ta;
                });

            setMessages(mapped);
        } catch (err) {
            console.error("Error fetching messages:", err);
        }
    }, [userName]);

    useEffect(() => {
        fetchMessages();
    }, [fetchMessages]);

    const showDialog = (id) => {
        setSelectedId(id);
        setVisible(true);
    };

    const hideDialog = () => {
        setVisible(false);
        setSelectedId(null);
    };

    const deleteMessage = () => {
        setMessages((prev) => prev.filter((m) => m.id !== selectedId));
        hideDialog();
    };

    return (
        <SafeAreaView style={styles.safe} edges={["top"]}>
            <ScrollView
                contentContainerStyle={styles.container}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        tintColor="#4f46e5"
                        colors={["#4f46e5"]}
                        title="Refreshing messages..."
                        titleColor="#6b7280"
                    />
                }
            >
                {/* Header */}
                <View style={styles.header}>
                    <Text variant="titleMedium" style={styles.greeting}>
                        {getGreeting()},
                    </Text>
                    <Text variant="headlineSmall" style={styles.name}>
                        {userName}
                    </Text>
                </View>

                {/* Messages */}
                {messages.map((msg) => {
                    const isExpanded = expandedIds.includes(msg.id);
                    const showExpand = (msg.subtitle || "").length > 80;

                    return (
                        <Card key={msg.id} style={styles.card}>
                            {/* Title Row */}
                            <Card.Title
                                title={msg.title}
                                right={() => (
                                    <View style={styles.rightContainer}>
                                        <Text style={styles.inlineTime}>
                                            {formatTime(msg.time)}
                                        </Text>

                                        <IconButton
                                            icon="delete"
                                            iconColor="#ef4444"
                                            size={20}
                                            onPress={() => showDialog(msg.id)}
                                        />
                                    </View>
                                )}
                            />

                            {/* Message Row with inline expand icon */}
                            <View style={styles.messageRow}>
                                <Text
                                    style={styles.messageText}
                                    numberOfLines={isExpanded ? undefined : 2}
                                >
                                    {msg.subtitle}
                                </Text>

                                {showExpand && (
                                    <IconButton
                                        icon={isExpanded ? "chevron-up" : "chevron-down"}
                                        size={18}
                                        onPress={() => toggleExpand(msg.id)}
                                        style={styles.expandIcon}
                                    />
                                )}
                            </View>
                        </Card>
                    );
                })}


                {/* Delete Dialog */}
                <Portal>
                    <Dialog visible={visible} onDismiss={hideDialog}>
                        <Dialog.Title>Delete Message</Dialog.Title>
                        <Dialog.Content>
                            <Text>
                                Are you sure you want to delete this message?
                            </Text>
                        </Dialog.Content>
                        <Dialog.Actions>
                            <Button onPress={hideDialog}>Cancel</Button>
                            <Button textColor="#ef4444" onPress={deleteMessage}>
                                Delete
                            </Button>
                        </Dialog.Actions>
                    </Dialog>
                </Portal>
            </ScrollView>
        </SafeAreaView>
    );
}

/* ------------------ Styles ------------------ */

const styles = StyleSheet.create({
    safe: {
        flex: 1,
    },
    container: {
        paddingBottom: 80,
    },
    header: {
        paddingHorizontal: 16,
        paddingVertical: 12,
    },
    greeting: {
        color: "#6b7280",
    },
    name: {
        fontWeight: "700",
    },
    card: {
        margin: 10,
        borderRadius: 6,
        elevation: 1,
    },
    rightContainer: {
        alignItems: "flex-end",
        justifyContent: "center",
        marginRight: 4,
    },
    inlineTime: {
        fontSize: 11,
        color: "#9ca3af",
        marginBottom: -4,
    },
    iconRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    messageBody: {
        paddingHorizontal: 16,
        paddingBottom: 12,
    },
    messageRow: {
        flexDirection: "row",
        alignItems: "flex-start",
        paddingHorizontal: 16,
        paddingBottom: 12,
    },

    messageText: {
        flex: 1,
        lineHeight: 20,
    },

    expandIcon: {
        marginTop: -4,
    },
});
