
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { router } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { AppState, Image, Keyboard, Platform, ScrollView, StyleSheet, ToastAndroid, TouchableWithoutFeedback, View } from "react-native";
import { Text, TextInput, useTheme } from "react-native-paper";
import HapticButton from "./components/HapticButton";


export default function Login() {
  // Configure notification behavior
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: true,
      shouldSetBadge: false,
    }),
  });
  const theme = useTheme();
  const colors = theme.colors;
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const scrollRef = useRef(null);

  // ==================== NOTIFICATION HANDLERS ====================
  const showNotification = (title, body) => {
    console.log('[Notification] Displaying notification:', { title, body });
    if (Platform.OS === 'android') {
      // ToastAndroid.show(`${title}: ${body}`, ToastAndroid.LONG);
    } else {
      // Alert.alert(title, body);
    }
  };

  // Handle navigation from notification tap (customize as needed)
  const handleNotificationNavigation = (data) => {
    // Example: navigate based on notification data
    if (data && data.target === 'messages') {
      router.replace('/(tabs)/messages');
    }
    // Add more navigation logic as needed
  };

  // Handle notification received while app is open
  useEffect(() => {
    const notificationListener = Notifications.addNotificationReceivedListener(notification => {
      console.log('[Notification] Received:', notification);
      showNotification(
        notification.request.content.title || 'New notification',
        notification.request.content.body || ''
      );
    });

    const responseListener = Notifications.addNotificationResponseReceivedListener(response => {
      console.log('[Notification] Response:', response);
      handleNotificationNavigation(response.notification.request.content.data);
    });

    // Check for notification that opened the app
    Notifications.getLastNotificationResponseAsync().then(response => {
      if (response?.notification) {
        console.log('[Notification] App opened from notification:', response.notification);
        handleNotificationNavigation(response.notification.request.content.data);
      }
    });

    return () => {
      notificationListener.remove();
      responseListener.remove();
    };
  }, []);

  const handleContinue = async () => {
    if (!username.trim()) return;

    setLoading(true);

    try {
      // register for push notifications and get token
      const tok = await registerForPushNotificationsAsync();
      if (tok) console.log('Notification Expo Token:', tok);

      // POST to register API with username and token
      try {
        const res = await fetch('https://ping-me-api.vercel.app/api/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: username.trim(), token: tok }),
        });

        const json = await res.json().catch(() => null);
        if (!res.ok) {
          ToastAndroid.show(`${json?.error || res.status}`, ToastAndroid.SHORT);
          console.log('Register API response', json);
          setLoading(false);
          return;
        } else {
          console.log('Register API response', json);
        }
      } catch (apiErr) {
        console.warn('Error calling register API', apiErr);
      }

      console.log('PingMe Username:', username);

      // persist username then navigate after API response
      try {
        await AsyncStorage.setItem('pingme_username', username.trim());
      } catch (err) {
        console.warn('Failed to save username', err);
      }

      setTimeout(() => {
        setLoading(false);
        router.replace("/(tabs)/messages");
      }, 800);
    } catch (err) {
      console.warn('Push token registration error', err);
      setLoading(false);
    }
  };

  useEffect(() => {
    // on mount, decide whether to show splash only on cold app open
    (async () => {
      try {
        const [storedUsername, splashFlag] = await Promise.all([
          AsyncStorage.getItem('pingme_username'),
          AsyncStorage.getItem('pingme_splash_shown'),
        ]);
        // If splash hasn't been shown before, show it for 2s then mark shown
        if (!splashFlag) {
          setTimeout(async () => {
            try {
              await AsyncStorage.setItem('pingme_splash_shown', '1');
            } catch (e) {
              console.warn('Failed to set splash flag', e);
            }

            if (storedUsername && storedUsername.trim()) {
              router.replace("/(tabs)/messages");
            } else {
              setShowSplash(false);
            }
          }, 2000);
        } else {
          // Splash already shown in this install/session — skip immediately
          setShowSplash(false);
          if (storedUsername && storedUsername.trim()) {
            router.replace("/(tabs)/messages");
          }
        }
      } catch (err) {
        console.warn('Error reading stored username or splash flag', err);
        setShowSplash(false);
      }
    })();

    const showSub = Keyboard.addListener("keyboardDidShow", (e) => {
      const height = e.endCoordinates?.height || 0;
      setKeyboardHeight(height);
      // scroll content so input is visible
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 50);
    });
    const hideSub = Keyboard.addListener("keyboardDidHide", () => {
      setKeyboardHeight(0);
      scrollRef.current?.scrollTo({ y: 0, animated: true });
    });
    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  // Check notification permission and log Expo token on app open / foreground
  useEffect(() => {
    let isMounted = true;

    const checkAndLogExpoToken = async () => {
      try {
        if (!Device.isDevice) {
          console.warn('[Notification] Must use physical device for push notifications');
          return;
        }

        const { status } = await Notifications.getPermissionsAsync();
        if (status === 'granted') {
          const tokenData = await Notifications.getExpoPushTokenAsync();
          const token = tokenData?.data ?? null;
          console.log('[Notification] Expo token:', token);
        } else {
          console.log('[Notification] Notification permission not granted');
        }
      } catch (err) {
        console.warn('[Notification] Error fetching expo token', err);
      }
    };

    // Run immediately on mount
    checkAndLogExpoToken();

    // Also run when app comes to foreground
    const subscription = AppState.addEventListener('change', nextAppState => {
      if (nextAppState === 'active') {
        checkAndLogExpoToken();
      }
    });

    return () => {
      if (subscription && subscription.remove) subscription.remove();
      isMounted = false;
    };
  }, []);

  // Helper: request permissions and get Expo push token
  async function registerForPushNotificationsAsync() {
    try {
      if (!Device.isDevice) {
        console.warn('Must use physical device for Push Notifications');
        return null;
      }

      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      if (finalStatus !== 'granted') {
        console.warn('Failed to get push token for push notification!');
        return null;
      }

      const tokenData = await Notifications.getExpoPushTokenAsync();
      const token = tokenData?.data ?? null;

      if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
          name: 'default',
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#FF231F7C',
        });
      }

      return token;
    } catch (err) {
      console.warn('Error while registering for push notifications', err);
      return null;
    }
  }

  if (showSplash) {
    return (
      <View style={[styles.splashContainer, { backgroundColor: colors.background }]}>
        <Image
          source={require("../assets/images/splash.png")}
          style={styles.splashImage}
          resizeMode="cover"
        />
      </View>
    );
  }

  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <ScrollView
        ref={scrollRef}
        style={[styles.scroll, { backgroundColor: colors.background }]}
        contentContainerStyle={[styles.container, { paddingBottom: keyboardHeight + 80 }]}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="interactive"
      >

        {/* Logo */}
        <Image
          source={require("../assets/images/pingme-logo.png")}
          style={styles.logo}
          resizeMode="contain"
        />

        {/* Title */}
        <Text variant="headlineMedium" style={styles.title}>
          PingMe
        </Text>

        {/* Tagline */}
        <Text variant="bodyMedium" style={[styles.subtitle, { color: colors.placeholder }]}>
          Get instant project error alerts on your phone
        </Text>

        {/* Illustration */}
        <Image
          source={require("../assets/images/dev-alert.png")}
          style={styles.illustration}
          resizeMode="contain"
        />

        {/* Description */}
        <Text variant="bodySmall" style={[styles.description, { color: colors.text }]}>
          When your project API throws an error, PingMe sends it directly to your
          mobile — so you never miss critical issues.
        </Text>

        {/* Username Input */}
        <TextInput
          label="Create Username"
          mode="outlined"
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
          style={[styles.input, { backgroundColor: '#f3f4f6' }]}
          contentStyle={{ paddingVertical: 10 }}
          outlineColor={colors.placeholder}
          activeOutlineColor={colors.primary}
          selectionColor={colors.primary}
          theme={{ ...theme, colors: { ...theme.colors, background: '#f3f4f6' } }}
        />

        {/* Button */}
        <HapticButton
          mode="contained"
          loading={loading}
          disabled={loading || !username.trim()}
          onPress={handleContinue}
          contentStyle={styles.buttonContent}
        >
          {loading ? "Connecting..." : "Continue"}
        </HapticButton>
      </ScrollView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
    backgroundColor: '#ffffffff',
  },

  container: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 60,
    justifyContent: 'flex-start',
  },

  logo: {
    width: 64,
    height: 64,
    alignSelf: "center",
    marginBottom: 12,
  },

  title: {
    textAlign: "center",
    marginBottom: 4,
  },

  subtitle: {
    textAlign: "center",
    color: "#6b7280",
    marginBottom: 20,
  },

  illustration: {
    width: "100%",
    height: 180,
    marginBottom: 20,
  },
  description: {
    textAlign: "center",
    color: "#4b5563",
    marginBottom: 24,
    paddingHorizontal: 8,
  },
  input: {
    marginBottom: 16,
  },
  buttonContent: {
    paddingVertical: 6,
  },
  splashContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  splashImage: {
    width: '100%',
    height: '100%',
  },
});

